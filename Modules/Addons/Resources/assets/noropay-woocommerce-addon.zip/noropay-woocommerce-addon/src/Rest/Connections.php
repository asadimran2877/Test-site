<?php

class Connections
{

    function __construct()
    {
        !defined('BASE_URL') ? define('BASE_URL', NOROPAY_WOOCOMMERCE_BASE_URL) : false;
    }

    public function noropay_execute($noropay_url, $noropay_method, $noropay_payload, $noropay_headers = null)
    {
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $noropay_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => false
        ));
        if( strtoupper($noropay_method) == "POST" ) {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $noropay_payload);
        }
        if( $noropay_headers != null ) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $noropay_headers);
        }
        $result = curl_exec($ch);
        $info =  curl_getinfo($ch, CURLINFO_HEADER_OUT);
        curl_close($ch);
        return $result;
    }
}