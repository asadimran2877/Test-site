<?php
/**
    * Plugin Name: Noropay-Woocommerce Addon
    * Plugin URI : https://noropay.com
    * Description: Noropay
    * Version: 1.0.0
    * Author: Norob BV
    * Author URI: https://noropay.com
    * License: GPL2
    * License URI: https://www.gnu.org/licenses/gpl-2.0.html
    * Text Domain: noropay-woocommerce-addon
    * Domain Path: /languages
*/

define('NOROPAY_WOOCOMMERCE_ADDON_DIR', trailingslashit(plugin_dir_path( __FILE__ )));
define('NOROPAY_WOOCOMMERCE_BRAND', 'Noropay');
!defined('NOROPAY_WOOCOMMERCE_BASE_URL') ? define('NOROPAY_WOOCOMMERCE_BASE_URL','https://noropay.com/') : false;

require_once  NOROPAY_WOOCOMMERCE_ADDON_DIR . 'src/includes.php' ;

add_action( 'plugins_loaded', function() {

    load_plugin_textdomain( 'noropay-woocommerce-addon', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );
    if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;

    include_once( 'src/Common/Noropay_ProcessWoocommerceGateway.php' );
    new Noropay_ProcessWoocommerceGateway();
});

add_action( 'init', function() {
    if ( isset( $_GET['noropay_woocommerce_payment_gateway'] ) ) {
        WC()->payment_gateways();
        do_action( 'noropay_check_woocommerce_payment_gateway' );
    }
});

add_filter( 'woocommerce_payment_gateways', function( $methods ) {
    $methods[] = 'Noropay_ProcessWoocommerceGateway';
    return $methods;
});