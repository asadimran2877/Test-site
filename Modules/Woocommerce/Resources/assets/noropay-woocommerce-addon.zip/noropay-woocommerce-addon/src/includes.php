<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once  NOROPAY_WOOCOMMERCE_ADDON_DIR . 'src/Api/Noropay_Payer.php' ;
require_once  NOROPAY_WOOCOMMERCE_ADDON_DIR . 'src/Api/Noropay_Amount.php' ;
require_once  NOROPAY_WOOCOMMERCE_ADDON_DIR . 'src/Api/Noropay_Transaction.php' ;
require_once  NOROPAY_WOOCOMMERCE_ADDON_DIR . 'src/Api/Noropay_RedirectUrls.php' ;
require_once  NOROPAY_WOOCOMMERCE_ADDON_DIR . 'src/Api/Noropay_Payment.php' ;