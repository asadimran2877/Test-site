<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once  NOROPAY_WOOCOMMERCE_ADDON_DIR . 'src/Common/Noropay_WoocommercePaymentGateway.php';

class Noropay_Amount extends Noropay_WoocommercePaymentGateway
{    
    public function noropay_set_total( $noropay_amount )
    {
        $this->noropay_total_amount = $noropay_amount;
        return $this;
    }

    public function noropay_get_total()
    {
        return $this->noropay_total_amount;
    }
    
    public function noropay_set_currency( $noropay_currency )
    {
        $this->noropay_currency = $noropay_currency;
        return $this;
    }

    public function noropay_get_currency()
    {
        return $this->noropay_currency;
    }
}