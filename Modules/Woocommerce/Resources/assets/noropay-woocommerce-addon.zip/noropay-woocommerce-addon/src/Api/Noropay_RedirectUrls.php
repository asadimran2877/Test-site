<?php 

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once  NOROPAY_WOOCOMMERCE_ADDON_DIR . 'src/Common/Noropay_WoocommercePaymentGateway.php';

class Noropay_RedirectUrls extends Noropay_WoocommercePaymentGateway 
{
    public function noropay_set_return_url( $noropay_url )
    {
        $this->noropay_return_url = $noropay_url;
        return $this;
    }

    public function noropay_get_return_url()
    {
        return $this->noropay_return_url;
    }

    public function noropay_set_cancel_url( $noropay_url )
    {
        $this->noropay_cancel_url = $noropay_url;
        return $this;
    }

    public function noropay_get_cancel_url()
    {
        return $this->noropay_cancel_url;
    }
}