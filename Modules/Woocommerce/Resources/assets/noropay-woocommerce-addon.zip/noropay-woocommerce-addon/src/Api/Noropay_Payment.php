<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once NOROPAY_WOOCOMMERCE_ADDON_DIR . 'src/Common/Noropay_WoocommercePaymentGateway.php';

class Noropay_Payment extends Noropay_WoocommercePaymentGateway
{    
    public function noropay_set_payer( $noropay_payer )
    {
        $this->noropay_payer = $noropay_payer;
        return $this;
    }

    public function noropay_get_payer()
    {
        return $this->noropay_payer;
    }

    public function noropay_set_transaction( $noropay_transaction )
    {
        $this->noropay_transaction = $noropay_transaction;
        return $this;
    }

    public function noropay_get_transaction()
    {
        return $this->noropay_transaction;
    }
    
    public function noropay_set_redirect_urls( $noropay_redirect_urls )
    {
        $this->noropay_redirect_urls = $noropay_redirect_urls;
        return $this;
    }

    public function noropay_get_redirect_urls()
    {
        return $this->noropay_redirect_urls;
    }

    public function noropay_set_credentials( $noropay_credentials )
    {
        $this->noropay_credentials = $noropay_credentials;
        return $this;
    }

    public function noropay_get_credentials()
    {
        return $this->noropay_credentials;
    }

    public function noropay_set_approved_url( $noropay_url )
    {
        $this->noropay_approved_url = $noropay_url;
        return $this;
    }

    public function noropay_get_approved_url()
    {
        return $this->noropay_approved_url;
    }

    public function noropay_create()
    {
        $noropay_access_token = $this->noropay_get_access_token();

        $noropay_approve_url  = $this->noropay_send_transaction_info( $noropay_access_token );

        if( $noropay_approve_url->status == 'error' ) {
            return $noropay_approve_url;
        }

        $this->noropay_set_approved_url( $noropay_approve_url );
    }

    private function noropay_get_access_token()
    {
        $noropay_array = $this->noropay_get_credentials();

        if ( ! $noropay_array['client_id'] || !$noropay_array['client_secret'] ) {
            esc_html_e( 'Parameter array must contain client_id and client_secret.', 'noropay-woocommerce-addon' ); exit;
        }

        $noropay_client_id = $noropay_array['client_id'];
        $noropay_client_secret = $noropay_array['client_secret'];
        $noropay_payload['client_id'] = $noropay_client_id;
        $noropay_payload['client_secret'] = $noropay_client_secret;
        $noropay_res = $this->noropay_execute( NOROPAY_WOOCOMMERCE_BASE_URL .'merchant/api/verify','post' , $noropay_payload );

        $noropay_res = json_decode( $noropay_res );
        if( ! $noropay_res ) {
            esc_html_e( 'Something went wrong, please try again later.', 'noropay-woocommerce-addon' ); exit;
        }
        if( $noropay_res->status == 'error' ) {
            esc_html_e($noropay_res->message); exit;
        }
        $response = $noropay_res->data->access_token;
        return $response;
    }

    private function noropay_send_transaction_info( $noropay_token )
    {
        $noropay_trans = $this->noropay_get_transaction();
        $noropay_payer = $this->noropay_get_payer();
        $noropay_redirect_urls = $this->noropay_get_redirect_urls();
        $noropay_amount = $noropay_trans->noropay_amount->noropay_get_total();
        $noropay_currency = $noropay_trans->noropay_amount->noropay_get_currency();
        $noropay_return_url = $noropay_redirect_urls->noropay_get_return_url();
        $noropay_cancel_url = $noropay_redirect_urls->noropay_get_cancel_url();
        $noropay_payment_method = $noropay_payer->noropay_get_payment_method();

        $noropay_req['payer'] = $noropay_payment_method;
        $noropay_req['amount'] = $noropay_amount;
        $noropay_req['currency']  = $noropay_currency;
        $noropay_req['successUrl'] = $noropay_return_url;
        $noropay_req['cancelUrl'] = $noropay_cancel_url;
        $noropay_req['items'] = json_encode( $noropay_trans->items );

        $noropay_header = ['Authorization: Bearer ' . $noropay_token];

        $noropay_res = $this->noropay_execute(NOROPAY_WOOCOMMERCE_BASE_URL . 'merchant/api/transaction-info', 'POST', $noropay_req, $noropay_header);

        $noropay_res = json_decode( $noropay_res );

        if ( ! $noropay_res ) {
            esc_html_e( 'Something went wrong, please try again later.', 'noropay-woocommerce-addon' ); exit;
        }

        if ( $noropay_res->status == 'error' ) {
            return $noropay_res;
        }

        $noropay_response = $noropay_res->data->approvedUrl;
        return $noropay_response;
    }
}