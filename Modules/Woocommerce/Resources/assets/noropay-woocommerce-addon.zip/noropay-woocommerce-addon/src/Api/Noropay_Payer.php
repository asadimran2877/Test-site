<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once  NOROPAY_WOOCOMMERCE_ADDON_DIR . 'src/Common/Noropay_WoocommercePaymentGateway.php' ;

class Noropay_Payer extends Noropay_WoocommercePaymentGateway 
{    
    public function Noropay_set_payment_method($noropay_method)
    {
        $this->noropay_payment_method = $noropay_method;
        return $this;
    }

    public function noropay_get_payment_method()
    {
        return $this->noropay_payment_method;
    }
}