<?php 

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once  NOROPAY_WOOCOMMERCE_ADDON_DIR . 'src/Common/Noropay_WoocommercePaymentGateway.php';


class Noropay_Transaction extends Noropay_WoocommercePaymentGateway 
{
    public function noropay_set_amount( $noropay_amount )
    {
        $this->noropay_amount = $noropay_amount;
        return $this;
    }

    public function noropay_get_amount()
    {
        return $this->noropay_amount;
    }

    public function noropay_set_items( $noropay_items )
    {
        $this->noropay_items = $noropay_items;
        return $this;
    }

    public function noropay_get_items()
    {
        return $this->noropay_items;
    }
}