<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once NOROPAY_WOOCOMMERCE_ADDON_DIR . 'src/Rest/Connections.php';

class Noropay_WoocommercePaymentGateway extends Connections
{
    public $noropay_props = [];

    public function __construct($data = null)
    {
        parent::__construct();
        $noropay_class = new \ReflectionClass($this);
        $noropay_methods = $noropay_class->getMethods();
        foreach ($noropay_methods as $noropay_method) {
            if ( !in_array($noropay_method->name, $this->noropay_props ) ) {
                $this->noropay_props[$noropay_method->name] = $noropay_method->name;
            }
        }
    }
}