<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Noropay_ProcessWoocommerceGateway extends WC_Payment_Gateway
{
    public function __construct()
    {
        $this->id = 'noropay_woocommerce_addon_id';
        $this->method_title = NOROPAY_WOOCOMMERCE_BRAND;
        /* translators: short description for payment gateway */
        $this->method_description = sprintf( esc_html__( 'WooCommerce Payment Gateway for %s', 'noropay-woocommerce-addon' ), NOROPAY_WOOCOMMERCE_BRAND );
        $this->title = NOROPAY_WOOCOMMERCE_BRAND;
        $this->has_fields = false;
        $this->supports = array('products');

        // Load the settings
        $this->initFormFields();
        $this->init_settings();

        // Get option from admin settings
        $this->enabled = $this->get_option('enabled');
        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');
        $this->client_id = $this->get_option('client_id');
        $this->client_secret = $this->get_option('client_secret');

        add_action( 'noropay_check_woocommerce_payment_gateway', array( $this, 'noropay_check_response') );

        if ( is_admin() ) {
            add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
        }
    }

    public function initFormFields()
    {
        $this->form_fields = array(

            'enabled' => array(
                'title' => esc_html__( 'Enable', 'noropay-woocommerce-addon' ),
                'type' => 'checkbox',
                /* translators: payment gateway enable/disable title */
                'label' => sprintf( esc_html__( 'Enable %s', 'noropay-woocommerce-addon' ), NOROPAY_WOOCOMMERCE_BRAND ),
                'default' => 'yes'
            ),
            'title' => array(
                'title' => esc_html__( 'Title', 'noropay-woocommerce-addon' ),
                'type' => 'text',
                'description' => esc_html__( 'This controls the title which the user sees during checkout.','noropay-woocommerce-addon' ),
                'default' => NOROPAY_WOOCOMMERCE_BRAND
            ),
            'description' => array(
                'title' => esc_html__( 'Description', 'noropay-woocommerce-addon' ),
                'type' => 'textarea',
                'description' => esc_html__( 'This controls the description which the user sees during checkout.', 'noropay-woocommerce-addon' ),
                /* translators: description that is display during checkout */
                'default' => sprintf( esc_html__( 'Pay with %s', 'noropay-woocommerce-addon' ), NOROPAY_WOOCOMMERCE_BRAND ),
            ),
            'client_id' => array(
                'title' => esc_html__( 'Client ID', 'noropay-woocommerce-addon' ),
                'type' => 'text',
                'default' => ''
            ),
            'client_secret' => array(
                'title' => esc_html__( 'Client Secret', 'noropay-woocommerce-addon' ),
                'type' => 'password',
                'default' => ''
            ),
        );
    }

    public function process_payment( $order_id )
    {
        $noropay_order = new WC_Order( $order_id );
        $noropay_order_data  = $noropay_order->get_data();

        // Get an instance of the WC_Order object
        $noropay_order = wc_get_order($order_id);
        $noropay_product = [];

        foreach ($noropay_order->get_items() as $key => $noropay_item) {
            $noropay_product[] = [
                'id' => $noropay_item->get_id(),
                'name' => $noropay_item->get_name(),
                'quantity' => $noropay_item->get_quantity(),
                'price' => $noropay_item->get_subtotal(),
            ];
        }

        $noropay_items = [
            'details' => $noropay_product,
            'shipping_cost' => $noropay_order_data['shipping_total'],
            'tax' => $noropay_order_data['total_tax'],
            'discount' => $noropay_order_data['discount_total'],
            'currency' => $noropay_order_data['currency'],
        ];

        $noropay_payer = new Noropay_Payer();
        $noropay_payer->noropay_set_payment_method( NOROPAY_WOOCOMMERCE_BRAND );

        $noropay_amount = new Noropay_Amount();
        $noropay_amount->noropay_set_total( $noropay_order->get_total() )->noropay_set_currency( get_woocommerce_currency() );

        $noropay_transaction = new Noropay_Transaction();
        $noropay_transaction->noropay_set_amount( $noropay_amount );
        $noropay_transaction->noropay_set_items( $noropay_items );

        $noropay_base_url = $this->get_return_url( $noropay_order );

        if ( strpos( $noropay_base_url, '?') !== false ) {
            $noropay_base_url .= '&';
        } else {
            $noropay_base_url .= '?';
        }

        $noropay_return_url = $noropay_base_url . 'noropay_woocommerce_payment_gateway=true&order_id=' . $order_id;

        $noropay_redirect_urls = new Noropay_RedirectUrls();
        $noropay_redirect_urls->noropay_set_return_url( $noropay_return_url )->noropay_set_cancel_url( $noropay_order->get_cancel_endpoint() );

        $noropay_payment = new Noropay_Payment();
        $noropay_payment->noropay_set_credentials([
            'client_id' => $this->get_option('client_id'),
            'client_secret' => $this->get_option('client_secret')
        ])
        ->noropay_set_redirect_urls($noropay_redirect_urls)
        ->noropay_set_payer($noropay_payer)
        ->noropay_set_transaction($noropay_transaction);

        try {

            $noropay_res = $noropay_payment->noropay_create();

            if ( $noropay_res->status == 'error' ) {
                wc_add_notice(  $noropay_res->message, 'error' );

                return array(
                    'result' => 'failure',
                    'redirect' => ''
                );
            }

            $noropay_approval_url = $noropay_payment->noropay_get_approved_url();

            return array(
                'result' => 'success',
                'redirect' => $noropay_approval_url
            );

        } catch (Exception $ex) {
            wc_add_notice( $ex->getMessage(), 'error' );
        }
        return array(
            'result' => 'failure',
            'redirect' => ''
        );
    }

    public function noropay_check_response()
    {
        global $woocommerce;

        if (isset($_GET['noropay_woocommerce_payment_gateway'])) {

            $noropay_woocommerce_pg = $_GET['noropay_woocommerce_payment_gateway'];
            $noropay_order_id = explode('?', $_GET['order_id']);
            $noropay_order_id = $noropay_order_id[0];

            if ( $noropay_order_id == 0 || $noropay_order_id == '' ) {
                return;
            }

            $noropay_order = new WC_Order( $noropay_order_id );
            if ($noropay_order->has_status('completed') || $noropay_order->has_status('processing')) {
                return;
            }

            // Get Payment method id
            $noropay_available_gateways = $woocommerce->payment_gateways->get_available_payment_gateways();
            $noropay_current_gateway    = '';

            if ( !empty( $noropay_available_gateways ) ) {
                if ( isset( $woocommerce->session->chosen_payment_method ) && isset( $noropay_available_gateways[ $woocommerce->session->chosen_payment_method ] ) ) {
                    $noropay_current_gateway = $noropay_available_gateways[ $woocommerce->session->chosen_payment_method ];
                }
            }
            $noropay_payment_id = $noropay_current_gateway->id;

            if ($noropay_woocommerce_pg == true) {
                $noropay_order->update_status('completed');

                $noropay_order->add_order_note( 
                /* translators: 1:payment method name 2:payment order id */
                sprintf( esc_html__( '%1$s payment approved, Transaction ID: %2$s.', 'noropay-woocommerce-addon', 'noropay-woocommerce-addon' ), $this->title, $noropay_order_id ) );
                $woocommerce->cart->empty_cart();
            }

            if ($noropay_woocommerce_pg == 'cancel') {
                $noropay_order = new WC_Order( $noropay_order_id );

                $noropay_order->update_status('cancelled', 
                /* translators: 1:payment method name 2:payment id */
                sprintf( esc_html__( '%1$s payment cancelled, Transaction ID: %2$d.', 'noropay-woocommerce-addon', 'noropay-woocommerce-addon' ), $this->title, $noropay_payment_id ) );
            }
        }
        return;
    }
}